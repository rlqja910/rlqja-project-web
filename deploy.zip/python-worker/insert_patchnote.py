import psycopg2
from datetime import datetime

conn = psycopg2.connect('postgres://neondb_owner:npg_u60UzqENSawH@ep-fancy-frost-azklg9ou-pooler.c-3.ap-southeast-1.aws.neon.tech/neondb?sslmode=require')
cur = conn.cursor()

version = 'v1.4.0'
content = '''[기능 업데이트]
- 방문자 수 카운트 방식 전면 개편: 이제 IP가 변경(와이파이/데이터 전환 등)되어도 동일한 방문자로 인식하도록 기기(브라우저) 기반 고유 ID를 부여했습니다. 이를 통해 '오늘 방문자' 및 '총 방문자' 데이터의 정합성을 완벽하게 보장합니다.

[버그 수정 및 최적화]
- 종목 측정 시 DB(데이터베이스)에 기록되는 시간 기준이 미국 기준(UTC)으로 저장되던 문제를 한국 시간(KST)으로 수정했습니다. 
- 스카우터 캐시 만료 기준 시간이 한국 시간 기준(밤 11시 59분 59초)으로 정확히 동작하도록 로직을 재정비했습니다.
- 아이폰(Safari) 및 아이패드 미니 등 모바일 환경에서 하단 메뉴 텍스트가 잘리거나, 우측 화면 여백이 발생하던 반응형 UI 레이아웃 버그를 완벽하게 고쳤습니다.'''

cur.execute("INSERT INTO patch_notes (version, content, created_at) VALUES (%s, %s, NOW() AT TIME ZONE 'Asia/Seoul')", (version, content))
conn.commit()

print('Patch note inserted successfully')
cur.close(); conn.close()
