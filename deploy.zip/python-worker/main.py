from fastapi import FastAPI, Query, BackgroundTasks
from pydantic import BaseModel
import requests
from bs4 import BeautifulSoup
import warnings
from bs4 import XMLParsedAsHTMLWarning
warnings.filterwarnings('ignore', category=XMLParsedAsHTMLWarning)
import google.generativeai as genai
import yfinance as yf
import json
import uuid
from typing import Dict, Any
import psycopg2
import re

DATABASE_URL = 'postgres://neondb_owner:npg_u60UzqENSawH@ep-fancy-frost-azklg9ou-pooler.c-3.ap-southeast-1.aws.neon.tech/neondb?sslmode=require'

app = FastAPI()

GEMINI_API_KEY = "AQ.Ab8RN6KFeQIj-DGm0B7rhsUv0-RMebrXdf6pEPeX_R_4HCS_jw"
genai.configure(api_key=GEMINI_API_KEY)
model = genai.GenerativeModel('gemini-flash-lite-latest')

class SummarizeResponse(BaseModel):
    success: bool
    title: str
    short_summary: str
    detailed_content: str
    hashtags: list[str]
    error: str | None = None

@app.get("/api/summarize-today", response_model=SummarizeResponse)
async def summarize_today_news():
    try:
        url = "https://news.google.com/rss/search?q=%ED%8A%B9%EC%A7%95%EC%A3%BC&hl=ko&gl=KR&ceid=KR:ko"
        response = requests.get(url)
        response.raise_for_status()
        soup = BeautifulSoup(response.content, 'html.parser')
        news_list = []
        for item in soup.find_all('item')[:20]:
            title_element = item.find('title')
            if title_element:
                news_list.append(f"뉴스 제목: {title_element.text.strip()}")
        if not news_list:
            return SummarizeResponse(success=False, title="", short_summary="", detailed_content="", hashtags=[], error="뉴스를 찾을 수 없습니다.")
        all_news_text = "\n\n".join(news_list[:15])
        prompt = (
            "너는 대한민국 최고의 주식 시장 애널리스트야.\n"
            "아래 제공된 '실시간 특징주 및 시황 속보' 기사들을 깊이 있게 분석해서, 투자자들이 열광할 만한 깔끔하고 트렌디한 증시 리포트를 작성해줘.\n"
            "글의 가독성을 높이기 위해 내용 중간중간에 이모지를 적당히 자연스럽게 섞어 넣어줘.\n"
            "결과물은 반드시 마크다운 포맷( ```json 텍스트 블록 안)으로 출력해야 하고, JSON 형식의 구조를 맞춰줘.\n\n"
            "형식:\n"
            "{\n"
            '  "title": "리포트의 매력적인 제목",\n'
            '  "short_summary": "전체 시황의 핵심을 관통하는 1~2줄 요약",\n'
            '  "detailed_content": ["특징주 1 분석", "특징주 2 분석", "시장 전망 등"],\n'
            '  "hashtags": ["해시태그1", "해시태그2"]\n'
            "}\n\n"
            f"오늘의 뉴스 속보:\n{all_news_text}"
        )
        response_gen = model.generate_content(prompt)
        result_text = response_gen.text.strip()
        result_text = re.sub(r'^```(?:json)?\s*', '', result_text, flags=re.IGNORECASE)
        result_text = re.sub(r'\s*```$', '', result_text).strip()
        result_json = json.loads(result_text)
        title = result_json.get("title", "오늘의 시황 분석")
        short_summary = result_json.get("short_summary", "")
        hashtags = result_json.get("hashtags", [])
        detailed_list = result_json.get("detailed_content", [])
        detailed_content_lines = []
        for line in detailed_list:
            if ":" in line:
                head, tail = line.split(":", 1)
                detailed_content_lines.append(f"**{head.strip()}**\n{tail.strip()}\n")
            elif "-" in line:
                head, tail = line.split("-", 1)
                detailed_content_lines.append(f"**{head.strip()}**\n{tail.strip()}\n")
            else:
                detailed_content_lines.append(f"{line.strip()}\n")
        detailed_content = "\n".join(detailed_content_lines).strip()
        return SummarizeResponse(success=True, title=title, short_summary=short_summary, detailed_content=detailed_content, hashtags=hashtags)
    except Exception as e:
        return SummarizeResponse(success=False, title="", short_summary="", detailed_content="", hashtags=[], error=str(e))

jobs: Dict[str, Any] = {}

def get_tier(cp: int) -> str:
    if cp >= 99000000: return "🌌 전왕(제노)급"
    if cp >= 95000000: return "⚪ 대신관급"
    if cp >= 90000000: return "💫 파괴신 비루스급"
    if cp >= 85000000: return "🌀 위스급 천사"
    if cp >= 80000000: return "🔵 초사이어인 블루"
    if cp >= 75000000: return "🔴 초사이어인 갓"
    if cp >= 70000000: return "💎 지렌급 (우주최강)"
    if cp >= 65000000: return "⚡ 초사이어인 3"
    if cp >= 58000000: return "🌀 고텐크스(퓨전)"
    if cp >= 52000000: return "💥 초사이어인 2"
    if cp >= 45000000: return "🩷 마인부우급"
    if cp >= 38000000: return "🐉 SSJ2 고한급"
    if cp >= 30000000: return "💚 완전체 셀급"
    if cp >= 22000000: return "🤖 인조인간 17호급"
    if cp >= 15000000: return "🟢 세미 퍼펙트 셀급"
    if cp >= 10000000: return "🧬 임퍼펙트 셀급"
    if cp >= 6000000:  return "☀️ 초사이어인 오공"
    if cp >= 3000000:  return "👊 나메크 전사급"
    if cp >= 1500000:  return "🧤 크리링/야무치급"
    if cp >= 700000:   return "❄️ 프리저 최종형태"
    if cp >= 300000:   return "🦎 바독(반란군)급"
    if cp >= 100000:   return "👾 기뉴 특전대급"
    if cp >= 30000:    return "🔴 자르본/도도리아"
    if cp >= 10000:    return "💀 라데츠급 전사"
    if cp >= 3000:     return "🐢 굴도급 (최약체)"
    if cp >= 500:      return "😢 야무치급 전사"
    if cp >= 100:      return "🙏 미스터 사탄급"
    if cp >= 10:       return "🏡 옥스킹 마을사람"
    return "🌾 전투력: 5 농부"

def process_scout(job_id: str, stockName: str):
    try:
        jobs[job_id] = {"status": "running"}

        ticker_prompt = (
            f"'{stockName}' 기업의 Yahoo Finance 티커와 사람들이 일반적으로 부르는 친숙하고 짧은 기업명(주식회사 등 꼬리표 제외)을 JSON으로만 출력해. 마크다운 금지.\n"
            "한국 유가증권(코스피) 종목은 .KS, 코스닥 종목은 .KQ 접미사를 반드시 붙여야 해.\n"
            "예시:\n"
            '  삼성전자주식회사 -> {"ticker":"005930.KS","realName":"삼성전자"}\n'
            '  에스엠씨지(유리용기회사) -> {"ticker":"460870.KQ","realName":"에스엠씨지"}\n'
            '  엔비디아 -> {"ticker":"NVDA","realName":"NVIDIA"}\n'
            f'출력: {{"ticker":"티커","realName":"짧은기업명"}}'
        )
        ticker_res = model.generate_content(ticker_prompt)
        t_text = ticker_res.text.strip()
        t_text = re.sub(r'^```(?:json)?\s*', '', t_text, flags=re.IGNORECASE)
        t_text = re.sub(r'\s*```$', '', t_text).strip()
        try:
            t_json = json.loads(t_text)
            ticker = t_json.get("ticker", "").strip().upper()
            real_stock_name = t_json.get("realName", stockName).strip()
        except:
            ticker = t_text.strip().upper()
            real_stock_name = stockName

        stock = yf.Ticker(ticker)
        hist = stock.history(period="1y")
        if hist.empty:
            raise ValueError(f"종목을 찾을 수 없습니다. 정확한 종목명이나 티커를 입력해 주세요. (AI 추정 티커: {ticker})")

        try:
            fi = stock.fast_info
            _lp = fi.last_price
            _yh = fi.year_high
            _yl = fi.year_low
            current_price = _lp if (_lp and _lp > 0) else float(hist['Close'].iloc[-1])
            high_1y = _yh if (_yh and _yh > 0) else float(hist['High'].max())
            low_1y = _yl if (_yl and _yl > 0) else float(hist['Low'].min())
        except Exception:
            current_price = float(hist['Close'].iloc[-1])
            high_1y = float(hist['High'].max())
            low_1y = float(hist['Low'].min())

        volume = int(hist['Volume'].iloc[-1])
        currency = "$" if not ticker.endswith((".KS", ".KQ")) else "₩"
        price_ratio = round((current_price / high_1y) * 100, 1) if high_1y and high_1y > 0 else 50.0
        if volume < 100000: volume_ratio_hint = "극빈"
        elif volume < 1000000: volume_ratio_hint = "빈약"
        elif volume < 10000000: volume_ratio_hint = "보통"
        else: volume_ratio_hint = "풍부"

        scouter_prompt = (
            f"너는 드래곤볼 스카우터 컨셉의 악랄하고 전투적인 주식 스카우터 AI야. "
            f"말투는 프리저나 베지터처럼 건방진 반말로, 구체적 수치를 근거로 타격감 넘치는 팩폭을 갈겨! 훈훈한 마무리 절대 금지.\n"
            f"종목: {real_stock_name} (티커: {ticker})\n"
            f"현재가: {currency}{current_price:.2f}, 52주 최고가: {currency}{high_1y:.2f}, 52주 최저가: {currency}{low_1y:.2f}\n"
            f"현재가/최고가 비율: {price_ratio}%, 거래량 수준: {volume_ratio_hint}({volume:,})\n\n"
            "[전투력 산정 기준 - 반드시 이 기준으로 계산해]:\n"
            "- 현재가/최고가 90%이상 + 거래량 풍부 -> 70000000 ~ 100000000\n"
            "- 현재가/최고가 70~90% + 거래량 보통 이상 -> 30000000 ~ 70000000\n"
            "- 현재가/최고가 50~70% -> 5000000 ~ 30000000\n"
            "- 현재가/최고가 30~50% -> 500000 ~ 5000000\n"
            "- 현재가/최고가 10~30% -> 10000 ~ 500000\n"
            "- 현재가/최고가 10% 미만 또는 거래량 극빈 -> 100 ~ 10000\n\n"
            "위 기준 엄격 준수. combatPower는 1~100000000 사이 순수 정수만.\n"
            "goodNews/badNews는 핵심 1줄. comment에 줄바꿈은 \\n. tier 필드 넣지마. 마크다운 금지.\n"
            f'출력: {{"combatPower": 15400, "goodNews": "호재", "badNews": "악재", "comment": "팩폭1\\n팩폭2"}}'
        )

        scout_res = model.generate_content(scouter_prompt)
        result_text = scout_res.text.strip()
        result_text = re.sub(r'^```(?:json)?\s*', '', result_text, flags=re.IGNORECASE)
        result_text = re.sub(r'\s*```$', '', result_text).strip()
        result_text = result_text.replace('\\"', '"')

        try:
            result_json = json.loads(result_text)
        except Exception:
            import ast
            try:
                result_json = ast.literal_eval(result_text)
            except:
                raise ValueError(f"AI 응답을 파싱할 수 없습니다: {result_text}")

        comment = result_json.get("comment", "분석 불가")
        if isinstance(comment, str):
            comment = comment.replace("\\n", "\n")

        _cp = int(re.sub(r"[^0-9]", "", str(result_json.get("combatPower", 0))) or 0)
        if _cp > 100000000: _cp = 100000000

        result_data = {
            "status": "done",
            "success": True,
            "stockName": real_stock_name,
            "ticker": ticker,
            "currency": currency,
            "combatPower": _cp,
            "tier": get_tier(_cp),
            "goodNews": result_json.get("goodNews", "-"),
            "badNews": result_json.get("badNews", "-"),
            "comment": comment,
            "currentPrice": float(current_price) if current_price else 0,
            "yearHigh": float(high_1y) if high_1y else 0,
            "yearLow": float(low_1y) if low_1y else 0
        }
        jobs[job_id] = result_data

        try:
            conn = psycopg2.connect(DATABASE_URL)
            cur = conn.cursor()
            cur.execute(
                "INSERT INTO scout_cache (stock_name, result_json, created_at) VALUES (%s, %s, NOW() AT TIME ZONE 'Asia/Seoul') ON CONFLICT (stock_name) DO UPDATE SET result_json = EXCLUDED.result_json, created_at = NOW() AT TIME ZONE 'Asia/Seoul'",
                (stockName, json.dumps(result_data, ensure_ascii=False))
            )
            conn.commit()
            cur.close()
            conn.close()
        except Exception as db_e:
            print("DB Cache Save Error:", db_e)

    except Exception as e:
        error_msg = str(e)
        if "429" in error_msg or "Quota" in error_msg:
            error_msg = "오늘 제공된 무료 API 호출 한도를 모두 소진했습니다. 😭"
        jobs[job_id] = {"status": "error", "success": False, "error": error_msg}

@app.get("/api/scout")
async def start_scout(background_tasks: BackgroundTasks, stockName: str = Query(..., min_length=1)):
    try:
        conn = psycopg2.connect(DATABASE_URL)
        cur = conn.cursor()
        cur.execute("SELECT result_json FROM scout_cache WHERE stock_name = %s AND created_at::date = (NOW() AT TIME ZONE 'Asia/Seoul')::date", (stockName,))
        row = cur.fetchone()
        cur.close()
        conn.close()
        if row:
            cached_data = json.loads(row[0])
            cached_data["status"] = "done"
            cached_data["success"] = True
            if "jobId" in cached_data:
                del cached_data["jobId"]
            return cached_data
    except Exception as e:
        print("Cache read error:", e)

    job_id = str(uuid.uuid4())
    background_tasks.add_task(process_scout, job_id, stockName)
    return {"jobId": job_id, "status": "pending"}

@app.get("/api/scout/result")
async def get_scout_result(jobId: str = Query(...)):
    if jobId not in jobs:
        return {"status": "error", "error": "Job not found"}
    return jobs[jobId]
