package com.example.demo.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;
import java.util.List;

@Component
public class PythonClient {
    private final WebClient webClient;

    public PythonClient(@Value("${app.python-worker.url}") String workerUrl) {
        this.webClient = WebClient.create(workerUrl);
    }

    public Mono<SummarizeResponse> fetchTodaySummary() {
        return webClient.get()
                .uri("/api/summarize-today")
                .retrieve()
                .bodyToMono(SummarizeResponse.class);
    }

    public static class SummarizeResponse {
        public boolean success;
        public String title;
        public String short_summary;
        public String detailed_content;
        public List<String> hashtags;
        public String error;
    }
}
