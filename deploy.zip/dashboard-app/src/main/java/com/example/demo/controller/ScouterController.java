package com.example.demo.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class ScouterController {
    private final RestTemplate restTemplate = new RestTemplate();
    private final String pythonWorkerUrl;

    public ScouterController(@org.springframework.beans.factory.annotation.Value("${app.python-worker.url}") String pythonWorkerUrl) {
        this.pythonWorkerUrl = pythonWorkerUrl;
    }

    @GetMapping("/scouter")
    public ResponseEntity<String> scoutStock(@RequestParam String stockName) {
        try {
            String url = pythonWorkerUrl + "/api/scout?stockName=" + stockName;
            String result = restTemplate.getForObject(url, String.class);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            String msg = e.getMessage() != null ? e.getMessage().replace("\"", "\\\"").replace("\n", " ") : "Unknown Error";
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("{\"success\":false, \"error\":\"" + msg + "\"}");
        }
    }
    
    @GetMapping("/scouter/result")
    public ResponseEntity<String> scoutResult(@RequestParam String jobId) {
        try {
            String url = pythonWorkerUrl + "/api/scout/result?jobId=" + jobId;
            String result = restTemplate.getForObject(url, String.class);
            return ResponseEntity.ok(result);
        } catch (Exception e) {
            String msg = e.getMessage() != null ? e.getMessage().replace("\"", "\\\"").replace("\n", " ") : "Unknown Error";
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                                 .body("{\"status\":\"error\", \"error\":\"" + msg + "\"}");
        }
    }
}
